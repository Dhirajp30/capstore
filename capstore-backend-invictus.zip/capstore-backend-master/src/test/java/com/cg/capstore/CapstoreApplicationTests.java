package com.cg.capstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
