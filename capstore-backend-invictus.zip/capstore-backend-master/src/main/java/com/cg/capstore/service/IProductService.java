package com.cg.capstore.service;

public interface IProductService {

}
