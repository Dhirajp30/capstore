package com.cg.capstore.controller;

public class ProductController {

}
