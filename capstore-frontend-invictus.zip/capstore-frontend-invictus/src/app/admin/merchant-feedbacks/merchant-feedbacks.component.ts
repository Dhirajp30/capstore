import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-feedbacks',
  templateUrl: './merchant-feedbacks.component.html',
  styleUrls: ['./merchant-feedbacks.component.css']
})
export class MerchantFeedbacksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
