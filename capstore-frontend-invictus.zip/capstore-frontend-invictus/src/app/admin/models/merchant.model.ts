export class Merchant{
    username: string;
    name: string;
    phoneNo: string;
    alternatePhoneNo: string;
    alternateEmail: string;
    gender: string;
    rating: number;
    thirdParty: boolean;
    deleted: boolean;
}