import { Merchant } from './merchant.model';

export class Invitation{
    header:string;
    message:string;
    merchant:Merchant;
}