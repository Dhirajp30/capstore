export class Transaction{
    transactionId:number;
    transactionDate:String;
    transactionMoney:number;
    transactionMethod:string;
    transactionStatus:string;
}