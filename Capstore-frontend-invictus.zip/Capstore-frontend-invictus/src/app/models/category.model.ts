export class Category{
     Id:number;
     categoryName:String;
}