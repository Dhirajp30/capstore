export class user{
    username:string;
    password:string;
    securityQuestion:string;
    securityAnswer:string;
    role:string;
    
}