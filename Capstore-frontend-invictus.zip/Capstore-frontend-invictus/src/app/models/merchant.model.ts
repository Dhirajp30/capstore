export class MerchantDetails{
    username:string;
    name:string;
    phoneNo:string;
    alternatePhoneNo:string;
    alternateEmail:string;
    gender:string;
    isDeleted:boolean;
    rating:number;
}