import { Category } from './category.model';

export class SubCategory{
    Id:number;
    name:String;
    category:Category;
}