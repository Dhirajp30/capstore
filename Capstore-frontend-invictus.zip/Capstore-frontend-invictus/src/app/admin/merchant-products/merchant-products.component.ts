import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-products',
  templateUrl: './merchant-products.component.html',
  styleUrls: ['./merchant-products.component.css']
})
export class MerchantProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
