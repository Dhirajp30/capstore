import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private router : Router) { }
  logOutUser() {
    if (localStorage.username != null) {
      localStorage.removeItem("token");
      this.router.navigate(['/home']);
    }
  }
}
