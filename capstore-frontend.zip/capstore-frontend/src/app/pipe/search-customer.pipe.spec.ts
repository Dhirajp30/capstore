import { SearchCustomerPipe } from './search-customer.pipe';

describe('SearchCustomerPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchCustomerPipe();
    expect(pipe).toBeTruthy();
  });
});
