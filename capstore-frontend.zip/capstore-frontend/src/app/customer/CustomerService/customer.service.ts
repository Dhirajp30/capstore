import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/app/models/user.model';
import { customer } from 'src/app/models/customer.model';



@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }

  registerNewUser(user: User) {

    return this.http.post("http://localhost:8080/createNewUser/", user,  { responseType: 'text' as 'json' });
  }
}
