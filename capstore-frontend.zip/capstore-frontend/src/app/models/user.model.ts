export class User{
    username:string;
    password:string;
    securityQuestion:string;
    securityAnswer:string;
    role:string;
    name:string;
    phoneNo:string;
    alternatePhoneNo:string;
    alternateEmail:string;
    gender:string;
}