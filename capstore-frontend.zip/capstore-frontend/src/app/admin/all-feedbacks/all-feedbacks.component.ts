import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-feedbacks',
  templateUrl: './all-feedbacks.component.html',
  styleUrls: ['./all-feedbacks.component.css']
})
export class AllFeedbacksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
