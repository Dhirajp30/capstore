import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-orders',
  templateUrl: './merchant-orders.component.html',
  styleUrls: ['./merchant-orders.component.css']
})
export class MerchantOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
