package com.cg.capstore.service;

import com.cg.capstore.response.UserDetails;

public interface ICustomerService {
	
	Long countOfCustomers() throws Exception;
	String createNewUser(UserDetails user);
}
