package com.cg.capstore.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.cg.capstore.dao.ICustomerDao;
import com.cg.capstore.entities.User;
import com.cg.capstore.repository.UserRepository;

@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService,UserDetailsService{

	
	@Autowired
	private ICustomerDao customerDao;
	
	@Autowired
	UserRepository userRepository;
	
	@Override
	public Long countOfCustomers() throws Exception {
		return customerDao.countOfCustomers();
	}

	@Override
	public String createNewUser( com.cg.capstore.response.UserDetails user) {
		return customerDao.createNewUser(user);
	}

	@Override
	public org.springframework.security.core.userdetails.UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), new ArrayList<>());
    }
	

}
