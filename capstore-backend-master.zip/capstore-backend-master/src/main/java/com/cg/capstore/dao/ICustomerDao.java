package com.cg.capstore.dao;

import com.cg.capstore.entities.User;
import com.cg.capstore.response.UserDetails;

public interface ICustomerDao {
	
	Long countOfCustomers() throws Exception;
	String createNewUser(UserDetails user);

}
