package com.cg.capstore.dao;

public class ProductDaoImpl implements IProductDao {

}
