import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-home',
  templateUrl: './merchant-home.component.html',
  styleUrls: ['./merchant-home.component.css']
})
export class MerchantHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
